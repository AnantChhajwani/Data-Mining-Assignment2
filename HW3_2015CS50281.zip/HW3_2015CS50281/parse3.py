import sys

f1 = open(sys.argv[1], "r")
f2 = open(sys.argv[2], "r")
f3 = open(sys.argv[3], "r")
f4 = open(sys.argv[4], "r")

g1 = open("my_train_dataset.txt", "w")
g2 = open("my_train_dataset_active.txt", "w")
g3 = open("my_train_dataset_inactive.txt", "w")

h = open("my_test_dataset.txt", "w")
h2 = open("train_dataset_label.txt", "w")

list_f1 = f1.readlines()
list_f2 = f2.readlines()
list_f3 = f3.readlines()
list_f4 = f4.readlines()

dict = {}
total = 0

dict_g2 = {}
dict_g3 = {}

for i in range(len(list_f2)):
	dict_g2[list_f2[i]] = 1

for i in range(len(list_f3)):
	dict_g3[list_f3[i]] = 1

for i in range(len(list_f1)):
	if list_f1[i][0] != '#':
		continue
	value = list_f1[i][1:]
	write_g2 = False
	if value in dict_g2:
		write_g2 = True
	write_g3 = False
	if value in dict_g3:
		write_g3 = True
	g1.write("t # " + value)
	if write_g2:
		h2.write("1\n")
		g2.write("t # " + value)
	if write_g3:
		h2.write("-1\n")
		g3.write("t # " + value)
	num_vertices = int(list_f1[i + 1])
	for j in range(num_vertices):
		s = str(list_f1[i + j + 2])
		if s not in dict:
			dict[s] = str(total)
			total += 1
		z = "v " + str(j) + " " + dict[s] + "\n"
		g1.write(z)
		if write_g2:
			g2.write(z)
		if write_g3:
			g3.write(z)
	num_edges = int(list_f1[i + num_vertices + 2])
	for j in range(num_edges):
		z = "e " + list_f1[i + j + num_vertices + 3]
		g1.write(z)
		if write_g2:
			g2.write(z)
		if write_g3:
			g3.write(z)

# test dataset remaining

for i in range(len(list_f4)):
	if list_f4[i][0] != '#':
		continue
	value = list_f4[i][1:]
	h.write("t # " + value)
	num_vertices = int(list_f4[i + 1])
	for j in range(num_vertices):
		s = str(list_f4[i + j + 2])
		if s not in dict:
			dict[s] = str(total)
			total += 1
		z = "v " + str(j) + " " + dict[s] + "\n"
		h.write(z)
	num_edges = int(list_f4[i + num_vertices + 2])
	for j in range(num_edges):
		z = "e " + list_f4[i + j + num_vertices + 3]
		h.write(z)

