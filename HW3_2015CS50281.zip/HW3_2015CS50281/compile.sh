chmod +x main.cpp
g++ -std=c++11 main.cpp -O3 -o main
cd gaston
chmod +x Makefile
make -f Makefile