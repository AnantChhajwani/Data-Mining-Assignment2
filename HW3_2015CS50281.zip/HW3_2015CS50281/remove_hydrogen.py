import sys

#print (sys.argv[1])
f = open(sys.argv[1], "r")
l = f.readlines()

g = open(sys.argv[1], "w")

for i in range(len(l)):
	if l[i][0] != '#':
		continue
	g.write(l[i])
	num_vertices = int(l[i + 1])
	node_labels = []
	for j in range(num_vertices):
		node_labels.append(l[i + j + 2])
	dict = {}
	cnt = 0
	for j in range(num_vertices):
		if node_labels[j] != 'H\n':
			dict[j] = cnt
			cnt += 1
	g.write(str(cnt) + '\n')
	for j in range(num_vertices):
		if node_labels[j] != 'H\n':
			g.write(node_labels[j])
	num_edges = int(l[i + num_vertices + 2])
	edges = []
	for j in range(num_edges):
		z = l[i + num_vertices + 3 + j].split()
		edges.append([int(z[0]), int(z[1]), int(z[2])])
	tot = 0
	new_edges = []
	for j in range(num_edges):
		if edges[j][0] in dict and edges[j][1] in dict:
			new_edges.append(str(dict[edges[j][0]]) + " " + str(dict[edges[j][1]]) + " " + str(edges[j][2]) + '\n')
			tot += 1
	g.write(str(tot) + '\n')
	for j in range(tot):
		g.write(new_edges[j])