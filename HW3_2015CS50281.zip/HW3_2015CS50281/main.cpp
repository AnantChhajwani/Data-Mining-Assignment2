#include <bits/stdc++.h>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/isomorphism.hpp>
#include <boost/property_map/property_map.hpp>
#include <boost/graph/vf2_sub_graph_iso.hpp>
#include <boost/graph/labeled_graph.hpp>

using namespace std;

typedef boost::property<boost::edge_name_t, int> edge_prop;
typedef boost::property<boost::vertex_name_t, int, boost::property<boost::vertex_index_t, int> > vertex_prop;

typedef boost::adjacency_list<boost::vecS, boost::vecS, boost::undirectedS, vertex_prop, edge_prop> Graph;

typedef boost::property_map<Graph, boost::vertex_name_t>::type vertex_name_map_t;
typedef boost::property_map_equivalent<vertex_name_map_t, vertex_name_map_t> vertex_comp_t;

typedef boost::property_map<Graph, boost::edge_name_t>::type edge_name_map_t;
typedef boost::property_map_equivalent<edge_name_map_t, edge_name_map_t> edge_comp_t;


template <typename Graph1, typename Graph2>
class my_call_back {

public:
	my_call_back(const Graph1& graph1, const Graph2& graph2) : graph1_(graph1), graph2_(graph2) {}

	template <typename CorrespondenceMap1To2, typename CorrespondenceMap2To1>
    bool operator()(CorrespondenceMap1To2 f, CorrespondenceMap2To1) { 
    	return true; 
    }

private:
	const Graph1& graph1_;
    const Graph2& graph2_;
};


bool is_subgraph_isomorphic(Graph smallGraph, Graph bigGraph) {
    vertex_comp_t vertex_comp =
        boost::make_property_map_equivalent(boost::get(boost::vertex_name, smallGraph), boost::get(boost::vertex_name, bigGraph));

    edge_comp_t edge_comp =
        boost::make_property_map_equivalent(boost::get(boost::edge_name, smallGraph), boost::get(boost::edge_name, bigGraph));

    my_call_back<Graph, Graph> callback(smallGraph, bigGraph);

    bool res = boost::vf2_subgraph_iso(smallGraph, bigGraph, callback, boost::vertex_order_by_mult(smallGraph),
        boost::edges_equivalent(edge_comp).vertices_equivalent(vertex_comp));

    return res;
}

void read_graph_database(string inputfile, vector<Graph> &vec) {
	ifstream infile (inputfile);
	string line;
	int id = -1;
	while(getline(infile, line)) {
		stringstream stream(line);
		char type;
		stream >> type;
		if(type == 't') {
			id++;
			vec.push_back(Graph());
			char c; int l;
			stream >> c >> l;
		}
		else if(type == 'v') {
			int nd, lbl;
			stream >> nd >> lbl;
			boost::add_vertex(vertex_prop(lbl), vec[id]);
		}
		else if(type == 'e') {
			int nd1, nd2, lbl;
			stream >> nd1 >> nd2 >> lbl;
			boost::add_edge(nd1, nd2, edge_prop(lbl), vec[id]);
		}
	}
}

void read_frequent_subgraphs(string inputfile, vector<Graph> &vec) {
    ifstream infile (inputfile);
    string line;
    int id = -1;
    while(getline(infile, line)) {
        if(line.at(0) == '#') continue;
        stringstream stream(line);
        char type;
        stream >> type;
        if(type == 't') {
            id++;
            vec.push_back(Graph());
            int l;
            stream >> l;
        }
        else if(type == 'v') {
            int nd, lbl;
            stream >> nd >> lbl;
            boost::add_vertex(vertex_prop(lbl), vec[id]);
        }
        else if(type == 'e') {
            int nd1, nd2, lbl;
            stream >> nd1 >> nd2 >> lbl;
            boost::add_edge(nd1, nd2, edge_prop(lbl), vec[id]);
        }
    }
}

int main(int argc, char* argv[]) {
	vector<Graph> train_dataset, test_dataset;
	read_graph_database("my_train_dataset.txt", train_dataset);
	read_graph_database("my_test_dataset.txt", test_dataset);

	vector<Graph> active_fsg, inactive_fsg;
	read_frequent_subgraphs("my_active_fsg.txt", active_fsg);
	read_frequent_subgraphs("my_inactive_fsg.txt", inactive_fsg);

	int active_size = active_fsg.size(), inactive_size = inactive_fsg.size();
	vector<bool> active_taken(active_size), inactive_taken(inactive_size);
	//cout << active_size << " " << inactive_size << endl;

	int a = 0, b = 0;
	for(int i = 0; i < active_size; i++) {
		active_taken[i] = true;
		a++;
		//cout << "i = " << i << endl;
		for(int j = 0; j < inactive_size; j++) {
			if(is_subgraph_isomorphic(active_fsg[i], inactive_fsg[j])) {
				active_taken[i] = false;
				a--;
				break;
			}
		}
	}
/*
	for(int i = 0; i < inactive_size; i++) {
		inactive_taken[i] = true;
		b++;
		cout << "i = " << i << endl;
		for(int j = 0; j < active_size; j++) {
			if(is_subgraph_isomorphic(inactive_fsg[i], active_fsg[j])) {
				inactive_taken[i] = false;
				b--;
				break;
			}
		}
	}
*/
	//cout << a << " " << b << endl;
	// self pruning actives
	
	for(int i = 0; i < active_size; i++) {
		if(!active_taken[i]) continue;
		for(int j = 0; j < active_size; j++) {
			if(!active_taken[j]) continue;
			if(j == i) continue;
			if(is_subgraph_isomorphic(active_fsg[i], active_fsg[j])) {
				active_taken[j] = false;
			}
		}
	}
	
	a = 0, b = 0;
	for(int i = 0; i < active_size; i++) {
		if(active_taken[i]) a++;
	}
	for(int i = 0; i < inactive_size; i++) {
		if(inactive_taken[i]) b++;
	}
	//cout << a << " " << b << endl;

	//cout << "isomorphism done" << endl;


	vector<Graph> features;
	for(int i = 0; i < active_size; i++) {
		if(active_taken[i]) {
			features.push_back(active_fsg[i]);
		}
	} 
	
	for(int i = 0; i < inactive_size; i++) {
		if(inactive_taken[i]) {
			features.push_back(inactive_fsg[i]);
		}
	}

	int num_features = features.size();
	//cout << num_features << endl;

	int train_size = train_dataset.size(), test_size = test_dataset.size();

	vector<int> train_labels[train_size], test_labels[test_size];

	for(int i = 0; i < train_size; i++)
		train_labels[i].resize(num_features);
	for(int i = 0; i < test_size; i++)
		test_labels[i].resize(num_features);

	for(int i = 0; i < num_features; i++) {
	//	cout << "i = " << i << endl;
		for(int j = 0; j < train_dataset.size(); j++) {
			if(is_subgraph_isomorphic(features[i], train_dataset[j]))
				train_labels[j][i] = 1;
			else
				train_labels[j][i] = -1;
		}
		for(int j = 0; j < test_dataset.size(); j++) {
			if(is_subgraph_isomorphic(features[i], test_dataset[j]))
				test_labels[j][i] = 1;
			else
				test_labels[j][i] = -1;
		}
	}

	vector<int> tr_lbl;
	ifstream infile ("train_dataset_label.txt");
	string line;
	while(getline(infile, line)) {
		stringstream stream(line);
		int k;
		stream >> k;
		tr_lbl.push_back(k);
	}
	// write output labels train and test
	//cout << tr_lbl.size() << " " << train_size << endl;
	ofstream outfile ("train.txt");
	for(int i = 0; i < train_size; i++) {
		outfile << tr_lbl[i] << " ";
		for(int j = 0; j < num_features; j++) {
			outfile << j << ":" << train_labels[i][j] << " ";
		}
		outfile << endl;
	}
	ofstream outfile2 ("test.txt");
	for(int i = 0; i < test_size; i++) {
		//outfile2 << 1 << " ";
		for(int j = 0; j < num_features; j++) {
			outfile2 << j << ":" << test_labels[i][j] << " ";
		}
		outfile2 << endl;
	}
	return 0;
}