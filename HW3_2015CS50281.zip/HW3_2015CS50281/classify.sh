#python break_aido.py
python remove_hydrogen.py $1
python remove_hydrogen.py $4
python parse3.py
num_actives=$(cat $2 | sed '/^\s*$/d' | wc -l)
echo $num_actives
num_inactives=$(cat $3 | sed '/^\s*$/d' | wc -l)
echo $num_inactives
support_actives=$(($num_actives/10))
if [ $support_actives -lt 60 ]; then
	support_actives=60
fi
echo $support_actives
support_inactives=$(($num_inactives/10))
echo $support_inactives
./gaston/gaston $support_actives my_train_dataset_active.txt my_active_fsg.txt
./gaston/gaston $support_inactives my_train_dataset_inactive.txt my_inactive_fsg.txt
./main
rm my_active_fsg.txt my_inactive_fsg.txt my_test_dataset.txt my_train_dataset.txt my_train_dataset_active.txt my_train_dataset_inactive.txt train_dataset_label.txt