#!/bin/bash

#Clone the repo
git clone https://github.com/AnantChhajwani/Data-Mining-Assignment2.git